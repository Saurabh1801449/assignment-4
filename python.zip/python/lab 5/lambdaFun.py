add = lambda x,y:x + y
sub = lambda x,y :x-y
mul = lambda x,y :x*y
sub = lambda x,y :x/y
print(add(10,20)) 
print(sub(10,20)) 
print(mul(10,20)) 
print(sub(10,20))
